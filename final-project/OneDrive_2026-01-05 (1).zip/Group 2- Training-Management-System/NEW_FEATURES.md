# Training Management System - New Features Implementation

## Features Implemented

### 1. Admin User Creation

The admin can now create new users (Employees or Trainers) directly from the admin dashboard.

**Location:** Admin Dashboard (`/admin`)

**How to use:**

1. Click on "Add New User" button
2. Fill in the form:
   - Name
   - Email
   - Password
   - Role (Employee or Trainer)
3. Click "Create User"
4. The new user will be added to the system and appear in the appropriate list

**Backend API:**

- **Endpoint:** `POST /api/admin/create-user`
- **Authorization:** Admin only (requires JWT token)
- **Request Body:**
  ```json
  {
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123",
    "role": "Employee"
  }
  ```

### 2. Course Assignment to Employees

Admin can now explore individual employees and assign courses to them.

**How to use:**

1. Navigate to Admin Dashboard (`/admin`)
2. In the Employees tab, click "Explore" button for any employee
3. You will be redirected to the employee detail page
4. View available courses and click "Assign Course" button to assign a course to the employee
5. The system will show a success message if the course is assigned or an error if the course is already assigned

**Backend API:**

- **Endpoint:** `POST /api/enroll`
- **Authorization:** Admin only
- **Request Body:**
  ```json
  {
    "courseId": "course_id_here",
    "userId": "user_id_here"
  }
  ```

## New Routes Added

### Frontend Routes:

- `/admin/employee/:id` - Employee detail page with course assignment functionality

### Backend Routes:

- `POST /api/admin/create-user` - Create new user (Admin only)

## Files Modified/Created

### Backend:

1. `BackEnd/src/controllers/adminController.js` - Added `createUser` function
2. `BackEnd/src/routes/adminRoutes.js` - Added route for creating users

### Frontend:

1. `FrontEnd/training-management-ui/src/app/pages/admin/admin-dashboard/admin-dashboard.ts` - Added user creation form logic
2. `FrontEnd/training-management-ui/src/app/pages/admin/admin-dashboard/admin-dashboard.html` - Added user creation form UI
3. `FrontEnd/training-management-ui/src/app/pages/admin/admin-dashboard/admin-dashboard.css` - Added styling
4. `FrontEnd/training-management-ui/src/app/pages/admin/employee-detail/employee-detail.ts` - Created employee detail component
5. `FrontEnd/training-management-ui/src/app/pages/admin/employee-detail/employee-detail.html` - Created employee detail template
6. `FrontEnd/training-management-ui/src/app/pages/admin/employee-detail/employee-detail.css` - Created styling
7. `FrontEnd/training-management-ui/src/app/app.routes.ts` - Added route for employee detail page

## How to Run the Application

### Backend:

```bash
cd BackEnd
npm install
npm start
```

The backend will run on `http://localhost:5000`

### Frontend:

```bash
cd FrontEnd/training-management-ui
npm install
npm start
```

The frontend will run on `http://localhost:4200`

## Testing the Features

1. **Login as Admin:**

   - Email: Use an admin account
   - Password: Your admin password

2. **Create a New User:**

   - Go to `/admin`
   - Click "Add New User"
   - Fill in the form and submit

3. **Assign Courses:**
   - Go to `/admin`
   - Click "Explore" on any employee
   - View available courses
   - Click "Assign Course" to assign a course to that employee

## Security Notes

- All admin endpoints are protected with JWT authentication
- Only users with "Admin" role can access these features
- Passwords are hashed using bcrypt before storing in the database
- Duplicate email addresses are prevented when creating users
- Duplicate course assignments are prevented

## Future Enhancements

- Bulk course assignment to multiple employees
- View assigned courses for each employee on the detail page
- Remove/unassign courses from employees
- Edit user details
- Delete users
