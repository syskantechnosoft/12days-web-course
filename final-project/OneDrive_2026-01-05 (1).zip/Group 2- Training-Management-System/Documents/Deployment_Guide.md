Backend Deployment (Local)
Copy code
Bash
cd BackEnd
npm install
npm run dev
Frontend Deployment (Local)
Copy code
Bash
cd FrontEnd/training-management-ui
npm install
ng serve
Environment Variables
Copy code
 
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/training_management_db
JWT_ACCESS_SECRET=****
JWT_REFRESH_SECRET=****