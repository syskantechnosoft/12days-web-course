Project Title
Training Management System (Corporate LMS)
Objective
To design and develop a role-based corporate LMS that allows Admins to manage trainings, Trainers to monitor progress, and Employees to complete assigned courses and obtain certificates.
Key Actors
Admin – Create & assign courses, manage employees
Trainer – Create courses, view trainee progress
Employee – Attend training, complete courses, download certificates
Functional Modules
Authentication & Authorization (JWT, RBAC)
Course Management
Enrollment & Assignment
Training Progress Tracking
Certification Generation
Role-based Dashboards (Admin, Trainer, Employee)


Non-Functional Requirements
Scalability: 500 concurrent users
Security: JWT, password hashing, RBAC
Availability: 99.9% uptime
Performance: <1s API response



Technology Stack
Frontend: Angular 21, TypeScript
Backend: Node.js, Express
Database: MongoDB (local)
Tools: VS Code, Thunder Client