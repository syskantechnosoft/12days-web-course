# Training Request and Approval Feature

## Overview

This feature allows employees to request training courses from the frontend, which can then be approved or rejected by admins through an admin dashboard interface.

## Features Implemented

### 1. Backend Changes

#### Enrollment Model Updates

- **New Fields Added:**
  - `requestStatus`: Tracks the status of training requests (Pending, Approved, Rejected, None)
  - `requestReason`: Stores the reason provided by the employee for requesting the training
  - `requestedBy`: Indicates whether the enrollment was initiated by an Employee or Admin
  - `rejectionReason`: Stores the admin's reason for rejecting a request (if applicable)

#### New API Endpoints

All routes are under `/api/enroll`:

1. **POST /request** (Employee only)

   - Allows employees to request training
   - Body: `{ courseId, reason }`
   - Creates enrollment with `requestStatus: 'Pending'`

2. **GET /pending-requests** (Admin only)

   - Retrieves all pending training requests
   - Returns full request details with employee and course information

3. **PATCH /approve/:requestId** (Admin only)

   - Approves a training request
   - Changes `requestStatus` from 'Pending' to 'Approved'

4. **PATCH /reject/:requestId** (Admin only)
   - Rejects a training request
   - Body: `{ rejectionReason }`
   - Changes `requestStatus` from 'Pending' to 'Rejected'

### 2. Frontend Changes

#### Employee Dashboard Updates

**File:** `dashboard.ts` and `dashboard.html`

- **Enhanced Request Modal:**

  - Employees can now submit actual training requests (not just alerts)
  - Request reason is required
  - Connects to backend API

- **Status Display:**
  - Shows different button states based on request status:
    - **Not Requested:** "Request Training" button (blue)
    - **Pending:** "⏳ Request Pending" button (disabled, yellow)
    - **Rejected:** "❌ Request Rejected" button with rejection reason and "Request Again" option
    - **Approved:** Normal "Continue Course" button

#### Admin Dashboard Updates

**Files:** `admin-dashboard.ts` and `admin-dashboard.html`

- **New "Training Requests" Tab:**

  - Added a fourth tab to the admin dashboard
  - Shows a badge with the count of pending requests
  - Displays table of all pending training requests

- **Request Details Modal:**

  - Shows complete information about the request:
    - Employee name and email
    - Course title, description, and duration
    - Request reason
    - Request timestamp
  - Actions available:
    - ✓ Approve Request
    - ✗ Reject Request (requires rejection reason)
    - Cancel

- **Real-time Updates:**
  - After approval/rejection, the pending requests list refreshes automatically
  - Notifications shown for successful actions

#### Service Updates

**File:** `enrollment.service.ts`

Added new methods:

- `requestTraining(courseId, reason)`
- `getPendingRequests()`
- `approveRequest(requestId)`
- `rejectRequest(requestId, rejectionReason)`

### 3. Styling Updates

**File:** `admin-dashboard.css`

- Added badge styling for request count notification
- Added request details modal styling
- Enhanced table styling for requests tab

## User Workflow

### Employee Flow:

1. Employee logs in and views available courses
2. Clicks "Request Training" on a course they're not enrolled in
3. Fills in the reason for requesting the training
4. Submits the request
5. Sees "Request Pending" status while waiting for admin approval
6. If rejected, can see the rejection reason and request again
7. If approved, can start the course

### Admin Flow:

1. Admin logs into the admin dashboard
2. Sees a badge on the "Training Requests" tab showing pending count
3. Clicks on "Training Requests" tab
4. Views table of all pending requests
5. Clicks "View Details" on a request
6. Reviews:
   - Employee information
   - Course details
   - Request reason
7. Decides to either:
   - **Approve:** Employee immediately gets access to the course
   - **Reject:** Must provide a rejection reason; employee sees this reason

## API Request/Response Examples

### Employee Requests Training

```javascript
POST /api/enroll/request
Headers: { Authorization: Bearer <employee_token> }
Body: {
  "courseId": "64abc123...",
  "reason": "I need this course to improve my skills in React"
}

Response: {
  "success": true,
  "message": "Training request submitted successfully",
  "enrollment": { ... }
}
```

### Admin Gets Pending Requests

```javascript
GET /api/enroll/pending-requests
Headers: { Authorization: Bearer <admin_token> }

Response: {
  "success": true,
  "requests": [
    {
      "_id": "64xyz789...",
      "courseId": {
        "title": "React Advanced",
        "description": "...",
        "duration": 120
      },
      "userId": {
        "name": "John Doe",
        "email": "john@example.com"
      },
      "requestReason": "I need this course to improve my skills in React",
      "requestStatus": "Pending",
      "createdAt": "2025-12-31T10:00:00.000Z"
    }
  ]
}
```

### Admin Approves Request

```javascript
PATCH /api/enroll/approve/64xyz789...
Headers: { Authorization: Bearer <admin_token> }

Response: {
  "success": true,
  "message": "Training request approved successfully",
  "enrollment": { ... }
}
```

### Admin Rejects Request

```javascript
PATCH /api/enroll/reject/64xyz789...
Headers: { Authorization: Bearer <admin_token> }
Body: {
  "rejectionReason": "This course is currently not available for your department"
}

Response: {
  "success": true,
  "message": "Training request rejected",
  "enrollment": { ... }
}
```

## Security Features

- All endpoints are protected with JWT authentication
- Role-based authorization ensures only employees can request and only admins can approve/reject
- Duplicate request prevention: Can't request same course multiple times if already pending or approved

## Database Schema

```javascript
Enrollment {
  courseId: ObjectId (required)
  userId: ObjectId (required)
  timeSpentInSeconds: Number (default: 0)
  progressStatus: String (Assigned/In Progress/Completed)
  requestStatus: String (Pending/Approved/Rejected/None)  // NEW
  requestReason: String                                    // NEW
  requestedBy: String (Employee/Admin)                     // NEW
  rejectionReason: String                                  // NEW
  assignedAt: Date
  completedAt: Date
  createdAt: Date (auto)
  updatedAt: Date (auto)
}
```

## Testing Instructions

### Test Employee Request Flow:

1. Login as an employee
2. Navigate to dashboard
3. Find a course not assigned to you
4. Click "Request Training"
5. Enter a reason and submit
6. Verify "Request Pending" button appears

### Test Admin Approval Flow:

1. Login as admin
2. Navigate to admin dashboard
3. Click "Training Requests" tab
4. Verify pending request appears
5. Click "View Details"
6. Click "Approve Request"
7. Verify request disappears from pending list
8. Login as employee and verify course is now accessible

### Test Admin Rejection Flow:

1. Login as admin
2. Navigate to admin dashboard
3. Click "Training Requests" tab
4. Click "View Details" on a request
5. Enter rejection reason
6. Click "Reject Request"
7. Verify request disappears
8. Login as employee and verify rejection message appears
9. Verify "Request Again" button is available

## Future Enhancements

- Email notifications to employees when requests are approved/rejected
- Bulk approval/rejection of multiple requests
- Training request history/audit log
- Request expiration after certain time period
- Comments/discussion thread on requests
