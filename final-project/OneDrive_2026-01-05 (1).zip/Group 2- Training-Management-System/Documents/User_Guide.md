# Training Management System - User Guide

## Table of Contents

1. [Admin Guide](#admin-guide)
2. [Trainer Guide](#trainer-guide)
3. [Employee Guide](#employee-guide)

---

## Admin Guide

### 1. Login as Admin

- Navigate to the application URL: `http://localhost:4200`
- Click **Login**
- Enter admin credentials:
  - Email: Your admin email
  - Password: Your admin password
- Click **Sign In**

### 2. Access Admin Dashboard

- After successful login, click on **Admin** in the navigation bar
- You will see the Admin Management dashboard with multiple tabs

### 3. How to Create a Course

#### Step-by-Step Course Creation:

**a) Open the Course Creation Form:**

- On the Admin Dashboard, click the **"Add Course"** button in the top-right corner
- A form will appear below the header

**b) Fill in Course Details:**

1. **Course Title** (Required)

   - Enter a clear, descriptive title
   - Example: "Python for Beginners", "Advanced Excel Training"
   - Best Practice: Keep it concise (3-8 words)

2. **Duration** (Required)

   - Enter the course duration in **minutes**
   - Example: 60, 120, 180
   - Best Practice: Be realistic about completion time

3. **Description** (Required)

   - Provide a comprehensive course description
   - Include:
     - What the course covers
     - Learning objectives
     - Prerequisites (if any)
     - Target audience
   - Example: "This course introduces Python programming fundamentals including variables, loops, functions, and object-oriented programming. Suitable for beginners with no prior coding experience."

4. **Content URL** (Optional)
   - Provide a link to the training materials
   - Supported formats:
     - **PDF documents**: Direct link to PDF file
     - **Video content**: YouTube, Vimeo, or direct video URLs
     - **External resources**: Any web-based training platform
   - Example: `https://www.youtube.com/embed/VIDEO_ID`
   - **Note:** If left empty, you can add materials later

**c) Submit the Course:**

- Click the **"Create Course"** button
- Wait for the success message: "Course created successfully"
- The form will automatically close after 2 seconds
- The new course will appear in the **Courses** tab

**d) Verify Course Creation:**

- Switch to the **"Courses"** tab
- Your newly created course should appear in the courses table
- Verify all details are correct

#### Course Management Tips:

✅ **Best Practices:**

- Create courses with clear, specific titles
- Always provide detailed descriptions
- Use realistic duration estimates
- Test content URLs before saving
- Consider adding materials immediately after creation

⚠️ **Common Mistakes to Avoid:**

- Missing required fields (title, description, duration)
- Invalid or broken content URLs
- Duration set to 0 or negative numbers
- Vague or unclear course titles

### 4. Assign Training to Employees

**Option A: Bulk Assignment from Admin Dashboard**

1. Navigate to **Admin Dashboard**
2. Click on the **"Courses"** tab
3. Find the course you want to assign
4. Click the **"Assign Course"** button on the course card
5. A modal will appear with a list of all employees
6. **Select employees:**
   - Use checkboxes to select multiple employees
   - The button shows count: "Assign to X Employee(s)"
7. Click **"Assign to X Employee(s)"**
8. Wait for success confirmation
9. The modal will close automatically

**Option B: Individual Assignment from Employee Detail**

1. Navigate to **Admin Dashboard**
2. Click on the **"Employees"** tab
3. Click **"Explore"** next to the employee's name
4. View the employee's current trainings
5. Click **"Assign Course"** button
6. Select a course from the dropdown
7. Click **"Assign"**
8. Confirmation message will appear

### 5. Monitor Training Progress

**View All Employees' Progress:**

1. Go to **Admin Dashboard**
2. Click **"Employees"** tab
3. Click **"Explore"** next to any employee
4. View their assigned trainings with:
   - Course titles
   - Status (Assigned/Completed)
   - Time spent
   - Completion dates

**View Training Requests:**

1. Check the **"Pending Requests"** column in the Employees table
2. If an employee has pending requests, click **"View Requests"**
3. Review the request details:
   - Course name
   - Request reason
   - Request date
4. **Approve:** Click "Approve Request" to enroll the employee
5. **Reject:** Enter rejection reason and click "Reject Request"

### 6. Manage Users

**Create New Users:**

1. Click **"Add New User"** button
2. Fill in the form:
   - **Name:** Full name of the user
   - **Email:** Valid email address (will be used for login)
   - **Password:** Secure password (min 6 characters)
   - **Role:** Select "Employee" or "Trainer"
3. Click **"Create User"**
4. Success message will confirm creation

---

## Trainer Guide

### 1. Login as Trainer

- Navigate to `http://localhost:4200`
- Enter trainer credentials
- Click **Sign In**

### 2. Access Trainer Dashboard

- Click **Trainer** in the navigation menu
- View your assigned courses and trainee status

### 3. Create Courses

- Trainers can also create courses using the same process as admins
- Navigate to **Trainer Dashboard**
- Follow the [Admin Course Creation Guide](#3-how-to-create-a-course)

### 4. View Trainee Progress

- See all enrollments for your courses
- Track completion status
- View time spent by each trainee

---

## Employee Guide

### 1. Login as Employee

- Navigate to `http://localhost:4200`
- Enter your email and password
- Click **Sign In**

### 2. View Available Courses

**From Dashboard:**

1. After login, you'll see the **Dashboard**
2. All available courses are displayed in card layout
3. Each card shows:
   - Course title and description
   - Duration
   - Status badge (if assigned to you)
   - Available actions

**Course Status Indicators:**

- **Yellow "Assigned" badge:** Course is assigned, not yet started
- **Green "Completed" badge:** You have completed this course
- **No badge:** Course is available but not assigned to you

### 3. Request Training

**If a course is not assigned to you:**

1. Find the course you want
2. Click **"Request Training"** button
3. A modal will open
4. Fill in:
   - **Reason:** Explain why you need this training
   - Example: "I need this to work on the new project"
5. Click **"Submit Request"**
6. Wait for admin approval
7. You'll see "Request Pending" status
8. Once approved, you can start the course

### 4. Access Your Trainings

**Option A: From Dashboard**

- Assigned courses show **"Continue Course"** button
- Click to start/resume training

**Option B: From My Trainings**

1. Click **"My Trainings"** in the navigation
2. View all your assigned trainings
3. See status: Assigned or Completed
4. Click **"Continue Training"** to start

### 5. Complete a Course

**Step-by-Step Completion:**

1. **Open the course:**

   - Click "Continue Training" or "Continue Course"
   - Course viewer will open

2. **View course materials:**

   - Materials load in the iframe viewer
   - You can click **"Open in New Tab"** for full-screen view

3. **Time tracking:**

   - Timer starts automatically when you open the course
   - Top section shows:
     - **Time Spent:** Your current session time
     - **Minimum Required:** Time needed to complete
   - Example: "Time Spent: 00:00:35 | Minimum Required: 00:00:30"

4. **Mark as complete:**
   - The **"Mark as Complete"** button is initially disabled
   - Wait until you've spent the minimum required time
   - Button shows countdown: "Complete after 00:00:15"
   - When time is met, button becomes enabled: **"Mark as Complete"**
   - Click the button
   - Confirm completion
   - Course status changes to **"Completed"**

**Important Notes:**

- ⏱️ You **cannot** mark a course complete until the minimum time requirement is met
- ⚠️ If you close the course viewer before completing, your time is saved
- ✅ Time spent accumulates across multiple sessions
- 🚫 You cannot skip or bypass the time requirement

### 6. Download Certificate

**After completing a course:**

1. Go to **Dashboard** or **My Trainings**
2. Find the completed course (Green "Completed" badge)
3. Click **"Download Certificate"** button
4. A PDF certificate will be generated and downloaded automatically
5. Certificate includes:
   - Your name
   - Course name
   - Completion date
   - Professional format

### 7. Tips for Employees

✅ **Best Practices:**

- Request courses that align with your role
- Start courses soon after assignment
- Don't rush - take time to understand materials
- Download certificates for your records
- Keep track of your completed trainings

⚠️ **Common Issues:**

**"Mark Complete" button is disabled:**

- Solution: Wait until minimum time requirement is met
- Check the time tracker at the top

**Cannot see course materials:**

- Solution: Check if contentUrl is provided
- Click "Open in New Tab" if iframe doesn't load

**Request not approved:**

- Solution: Check with your admin
- View rejection reason if provided
- You can request again with updated reason

---

## Technical Requirements

### System Requirements:

- Modern web browser (Chrome, Firefox, Edge, Safari)
- Internet connection
- JavaScript enabled

### Minimum Time Requirement:

- Default: **30 seconds** per course
- Configurable by system administrator
- Cannot be bypassed by employees

### Supported Content Formats:

- PDF documents
- YouTube videos (embed format)
- Vimeo videos
- External web links
- Any iframe-compatible content

---

## Troubleshooting

### Cannot Login:

- Verify email and password are correct
- Check if account is active
- Contact administrator for password reset

### Course Not Loading:

- Refresh the page
- Check internet connection
- Verify content URL is valid
- Try "Open in New Tab" option

### Training Request Failed:

- Ensure you're logged in
- Check if backend server is running
- Clear browser cache and retry
- Contact administrator if issue persists

### Certificate Not Downloading:

- Allow pop-ups in browser settings
- Check download folder
- Try a different browser
- Ensure course is marked as "Completed"

---

## Support

For additional support or questions:

- Contact your system administrator
- Check the API documentation: `Documents/API_Documentation.md`
- Review the Testing Plan: `Documents/Testing_Plan.md`

---

**Version:** 2.0  
**Last Updated:** December 2025  
**System:** Training Management System
