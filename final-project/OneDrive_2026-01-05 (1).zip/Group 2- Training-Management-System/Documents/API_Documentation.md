Authentication APIs
Method
Endpoint
Description
POST
/api/auth/register
Register user
POST
/api/auth/login
Login user
GET
/api/auth/employees
Get employees (Admin)
Course APIs
Method
Endpoint
Access
POST
/api/courses
Admin/Trainer
GET
/api/courses
All logged users
GET
/api/courses/trainer
Trainer
Enrollment APIs
Method
Endpoint
Access
POST
/api/enroll
Admin
GET
/api/enroll/my
Employee
PATCH
/api/enroll/complete
Employee



All protected APIs require:
Copy code
 
Authorization: Bearer <JWT>