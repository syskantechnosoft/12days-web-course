Unit Testing (Documented)
Token validation logic
Time-spent validation
Integration Testing (Thunder Client)
Register → Login → Token
Admin assigns course
Employee completes course
E2E (Manual)
Admin creates course
Admin assigns course
Employee completes course
Certificate downloaded