import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot } from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class RoleGuard implements CanActivate {

    constructor(private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot): boolean {
        const role = localStorage.getItem('role');
        const path = route.routeConfig?.path;

        // Allow Admin to access admin routes and view employee trainings
        if (role === 'Admin') {
            return true;
        }

        // Allow Employee to access their own trainings (no :id param)
        if (role === 'Employee' && path === 'my-trainings') {
            return true;
        }

        // Not authorized → redirect
        this.router.navigate(['/dashboard']);
        return false;
    }
}