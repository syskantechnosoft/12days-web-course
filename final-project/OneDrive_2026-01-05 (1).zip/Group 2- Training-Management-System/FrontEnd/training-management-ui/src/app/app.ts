import { Component, signal } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { LoginComponent } from './pages/auth/login/login';
import { NavbarComponent } from './components/navbar/navbar';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-root',
  standalone:true,
  imports: [ RouterOutlet,NavbarComponent,CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  constructor(public router:Router){}
  
  get isLoggedIn(): boolean {
    return !!localStorage.getItem('accessToken');
  }

  protected readonly title = signal('training-management-ui');
}
