import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class EnrollmentService {

    private baseUrl = 'http://localhost:5000/api/enroll';

    constructor(private http: HttpClient) { }

    getMyTrainings(): Observable<any> {
        return this.http.get(`${this.baseUrl}/my`);
    }
    
    getEmployeeTrainings(employeeId: string): Observable<any> {
        return this.http.get(`${this.baseUrl}/employee/${employeeId}`);
    }
    
    assignCourse(courseId: string, userId: string) {
        return this.http.post(this.baseUrl, { courseId, userId });
    }
    
    updateProgress(enrollmentId: string, timeSpentInSeconds: number): Observable<any> {
        return this.http.patch(`${this.baseUrl}/progress`, {
            enrollmentId,
            timeSpentInSeconds
        });
    }
    
    completeTraining(enrollmentId:string,timeSpentInSeconds:number){
        return this.http.patch(`${this.baseUrl}/complete`,{
            enrollmentId,timeSpentInSeconds
        });
    }

    requestTraining(courseId: string, reason: string): Observable<any> {
        return this.http.post(`${this.baseUrl}/request`, { courseId, reason });
    }

    getPendingRequests(): Observable<any> {
        return this.http.get(`${this.baseUrl}/pending-requests`);
    }

    approveRequest(requestId: string): Observable<any> {
        return this.http.patch(`${this.baseUrl}/approve/${requestId}`, {});
    }

    rejectRequest(requestId: string, rejectionReason: string): Observable<any> {
        return this.http.patch(`${this.baseUrl}/reject/${requestId}`, { rejectionReason });
    }
}