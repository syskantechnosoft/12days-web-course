import { Injectable } from '@angular/core';
import jsPDF from 'jspdf';

@Injectable({
    providedIn: 'root'
})
export class CertificateService {

    generateCertificate(
        employeeName: string,
        courseName: string,
        completionDate: string
    ): void {
        const doc = new jsPDF();

        doc.setFontSize(22);
        doc.text('Certificate of Completion', 105, 30, { align: 'center' });

        doc.setFontSize(14);
        doc.text(
            `This is to certify that`,
            105,
            50,
            { align: 'center' }
        );

        doc.setFontSize(18);
        doc.text(employeeName, 105, 65, { align: 'center' });

        doc.setFontSize(14);
        doc.text(
            `has successfully completed the course`,
            105,
            80,
            { align: 'center' }
        );

        doc.setFontSize(16);
        doc.text(courseName, 105, 95, { align: 'center' });

        doc.setFontSize(12);
        doc.text(
            `Date of Completion: ${completionDate}`,
            105,
            115,
            { align: 'center' }
        );

        doc.save(`${courseName}-Certificate.pdf`);
    }
}
