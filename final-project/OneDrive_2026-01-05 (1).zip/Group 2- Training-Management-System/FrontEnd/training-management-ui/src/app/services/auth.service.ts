// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { EmployeesResponse } from '../models/api-response.model';


// @Injectable({
//     providedIn: 'root'
// })
// export class AuthService {

//     private baseUrl = 'http://localhost:5000/api/auth';

//     constructor(private http: HttpClient,
//         private authService: AuthService,
//     ) {
//         this.authService.initAuthState();
      
//      }

//     login(email: string, password: string): Observable<any> {
//         return this.http.post(`${this.baseUrl}/login`, { email, password });
//     }

//     getEmployees() {
//         return this.http.get<EmployeesResponse>(`${this.baseUrl}/employees`);
//     }
//     saveAuthData(response: any): void {
//         localStorage.setItem('accessToken', response.accessToken);
//         localStorage.setItem('refreshToken', response.refreshToken);
//         localStorage.setItem('role', response.role);
//     }

//     isLoggedIn(): boolean {
//         return !!localStorage.getItem('accessToken');
//     }
//     initAuthState(): void {
//         if (localStorage.getItem('accessToken')) {
//             return;
//         }
//     }

//     logout(): void {
//         localStorage.clear();
//     }
// }

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EmployeesResponse } from '../models/api-response.model';
@Injectable({
    providedIn: 'root'
})
export class AuthService {

    private baseUrl = 'http://localhost:5000/api/auth';

    constructor(private http: HttpClient) { }

    login(email: string, password: string): Observable<any> {
        return this.http.post(`${this.baseUrl}/login`, { email, password });
    }

    saveAuthData(response: any): void {
        localStorage.setItem('accessToken', response.accessToken);
        localStorage.setItem('refreshToken', response.refreshToken);
        localStorage.setItem('role', response.role);
        localStorage.setItem('userName', response.userName || 'User');
        localStorage.setItem('userId', response.userId || '');
        console.log('Auth data saved:', {
            role: response.role,
            userName: response.userName,
            userId: response.userId
        });
    }
    getEmployees() {
            return this.http.get<EmployeesResponse>(`${this.baseUrl}/employees`);
        }

    logout(): void {
        localStorage.clear();
    }

    isLoggedIn(): boolean {
        return !!localStorage.getItem('accessToken');
    }
}
