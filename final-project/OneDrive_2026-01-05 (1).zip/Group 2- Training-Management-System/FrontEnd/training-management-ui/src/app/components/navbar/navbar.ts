import { Component } from '@angular/core';

import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone:true,
  imports: [RouterModule,CommonModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class NavbarComponent {

  role = localStorage.getItem('role');

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  logout(): void {
    console.log('Logout clicked');
    this.authService.logout();
    console.log('Auth data cleared');
    this.router.navigate(['/login']).then(() => {
      console.log('Navigated to login');
      window.location.reload(); // Force reload to clear all state
    });
  }
}
