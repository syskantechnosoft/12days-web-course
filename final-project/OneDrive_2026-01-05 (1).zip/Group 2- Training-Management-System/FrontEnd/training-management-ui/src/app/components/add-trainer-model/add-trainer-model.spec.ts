import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTrainerModel } from './add-trainer-model';

describe('AddTrainerModel', () => {
  let component: AddTrainerModel;
  let fixture: ComponentFixture<AddTrainerModel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddTrainerModel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddTrainerModel);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
