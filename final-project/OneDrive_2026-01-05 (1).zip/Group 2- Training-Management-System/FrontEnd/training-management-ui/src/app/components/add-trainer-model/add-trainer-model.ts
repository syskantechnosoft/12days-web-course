import { Component } from '@angular/core';

@Component({
  selector: 'app-add-trainer-model',
  imports: [],
  templateUrl: './add-trainer-model.html',
  styleUrl: './add-trainer-model.css',
})
export class AddTrainerModel {

}
