import { Routes } from '@angular/router';
import { LoginComponent } from './pages/auth/login/login';
import { Dashboard } from './pages/dashboard/dashboard';
import { AuthGuard } from './guards/auth.guard';
import { CourseListComponent } from './pages/courses/course-list/course-list';
import { MyTrainingsComponent } from './pages/trainings/my-trainings/my-trainings';
import { AdminDashboardComponent } from './pages/admin/admin-dashboard/admin-dashboard';
import { EmployeeDetailComponent } from './pages/admin/employee-detail/employee-detail';
import { RoleGuard } from './guards/role.guard';
import { TrainerDashboardComponent } from './pages/trainer/trainer-dashboard/trainer-dashboard';
import { DashboardResolver } from './resolver/dashboard.resolver';

export const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    // {
    //     path: 'dashboard',
    //     component: Dashboard,
    //     canActivate:[AuthGuard]
    // },
    {
        path: 'dashboard',
        component: Dashboard,
        canActivate: [AuthGuard],
        resolve: {
            dashboardData: DashboardResolver
        }
    },
    {
        path: 'courses',
        component: CourseListComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'my-trainings',
        component: MyTrainingsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'my-trainings/:id',
        component: MyTrainingsComponent,
        canActivate: [AuthGuard, RoleGuard]
    },
    // {
    //     path: 'my-trainings',
    //     loadComponent: () =>
    //         import('./pages/trainings/my-trainings/my-trainings')
    //             .then(m => m.MyTrainingsComponent),
    //     canActivate: [AuthGuard]
    // },
    {
        path: 'admin',
        component: AdminDashboardComponent,
        canActivate: [AuthGuard,RoleGuard]
    },
    {
        path: 'admin/employee/:id',
        component: EmployeeDetailComponent,
        canActivate: [AuthGuard, RoleGuard]
    },
    {
        path: 'trainer',
        component: TrainerDashboardComponent,
        canActivate: [AuthGuard]
    },

    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    
];