import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { EnrollmentService } from '../services/enrollment.service';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class DashboardResolver implements Resolve<any> {

    constructor(private enrollmentService: EnrollmentService) { }

    resolve(): Observable<any> {
        const role = localStorage.getItem('role');

        if (role !== 'Employee') {
            return of({ enrollments: [] });
        }

        return this.enrollmentService.getMyTrainings().pipe(
            catchError(() => of({ enrollments: [] }))
        );
    }
}