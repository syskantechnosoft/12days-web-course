export interface Course{
    _id:string;
    title: string;
    description: string;
    duration:number;
    contentUrl: string;
}