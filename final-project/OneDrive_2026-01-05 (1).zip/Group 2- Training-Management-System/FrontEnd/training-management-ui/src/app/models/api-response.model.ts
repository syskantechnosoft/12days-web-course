import { User } from './user.model';

export interface EmployeesResponse {
    success: boolean;
    users: User[];
}