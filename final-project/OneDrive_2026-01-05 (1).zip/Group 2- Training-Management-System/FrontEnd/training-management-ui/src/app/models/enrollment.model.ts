import { Course } from "./course.model";

export interface Enrollment{
    _id:string;
    progressStatus:'Assigned' | 'In Progress' |'Completed';
    timeSpentInSeconds:number;
    courseId: Course
}