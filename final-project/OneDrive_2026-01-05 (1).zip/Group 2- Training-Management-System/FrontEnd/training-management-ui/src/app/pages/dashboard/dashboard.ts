
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink ,ActivatedRoute} from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../services/course.service';
import { EnrollmentService } from '../../services/enrollment.service';
import { CertificateService } from '../../services/certificate.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit {

  role = localStorage.getItem('role');
  loading = true;

  courses: any[] = [];
  enrollments: any[] = [];
  mergedCourses: any[] = [];
  employees: any[] = [];

  // Employee: Request Training Modal
  showRequestForm = false;
  selectedCourse: any = null;
  requestData = {
    reason: ''
  };

  // Admin: Assign Course Modal
  showAssignModal = false;
  selectedCourseForAssign: any = null;
  selectedEmployeeIds: string[] = [];

  constructor(
    private courseService: CourseService,
    private enrollmentService: EnrollmentService,
    private certificateService: CertificateService,
    private http: HttpClient,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    if (this.role === 'Employee') {
      this.loadEmployeeDashboard();
    } else if (this.role === 'Admin') {
      this.loadAdminDashboard();
    } else {
      this.loading = false;
    }
  }

  // ==================== EMPLOYEE DASHBOARD ====================
  loadEmployeeDashboard(): void {
    this.courseService.getCourses().subscribe({
      next: (courseRes) => {
        this.courses = courseRes.courses;

        this.enrollmentService.getMyTrainings().subscribe({
          next: (enrollRes) => {
            this.enrollments = enrollRes.enrollments;
            this.mergeCourses();
            this.loading = false;
          },
          error: () => this.loading = false
        });
      },
      error: () => this.loading = false
    });
  }

  mergeCourses(): void {
    this.mergedCourses = this.courses.map(course => {
      const enrollment = this.enrollments.find(
        e => e.courseId._id === course._id
      );

      // Check if there's a pending request
      const hasPendingRequest = enrollment && enrollment.requestStatus === 'Pending';
      const isRejected = enrollment && enrollment.requestStatus === 'Rejected';
      const isApproved = enrollment && (enrollment.requestStatus === 'Approved' || enrollment.requestStatus === 'None');

      return {
        ...course,
        isAssigned: !!(enrollment && isApproved),
        progressStatus: enrollment?.progressStatus,
        enrollmentId: enrollment?._id,
        requestStatus: enrollment?.requestStatus,
        hasPendingRequest,
        isRejected,
        rejectionReason: enrollment?.rejectionReason
      };
    });
  }

  openRequestForm(course: any): void {
    // Check if user is logged in
    const token = localStorage.getItem('accessToken');
    const role = localStorage.getItem('role');
    
    console.log('Opening request form:', {
      hasToken: !!token,
      role: role,
      course: course.title
    });

    if (!token) {
      alert('You must be logged in to request training');
      return;
    }

    if (role !== 'Employee') {
      alert('Only employees can request training');
      return;
    }

    this.selectedCourse = course;
    this.showRequestForm = true;
  }

  submitRequest(): void {
    if (!this.requestData.reason || this.requestData.reason.trim() === '') {
      alert('Please provide a reason for your training request');
      return;
    }

    if (!this.selectedCourse || !this.selectedCourse._id) {
      alert('No course selected');
      return;
    }

    const token = localStorage.getItem('accessToken');
    const role = localStorage.getItem('role');
    
    console.log('=== Submitting Training Request ===');
    console.log('Course ID:', this.selectedCourse._id);
    console.log('Course Title:', this.selectedCourse.title);
    console.log('Reason:', this.requestData.reason);
    console.log('Has Token:', !!token);
    console.log('Role:', role);
    console.log('API Endpoint:', 'http://localhost:5000/api/enroll/request');

    this.enrollmentService.requestTraining(
      this.selectedCourse._id,
      this.requestData.reason
    ).subscribe({
      next: (res) => {
        console.log('✓ Request successful:', res);
        alert('Training request submitted successfully! Waiting for admin approval.');
        this.closeRequestForm();
        // Reload the dashboard to show pending status
        this.loadEmployeeDashboard();
      },
      error: (err) => {
        console.error('✗ Request failed:', err);
        console.error('Error details:', {
          status: err.status,
          statusText: err.statusText,
          error: err.error,
          message: err.message,
          url: err.url
        });
        
        let errorMessage = 'Failed to submit training request';
        
        if (err.status === 0) {
          errorMessage = 'Cannot connect to server. Please ensure the backend is running on port 5000.';
        } else if (err.status === 401) {
          errorMessage = 'Authentication failed. Please log in again.';
          // Optionally redirect to login
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        } else if (err.status === 403) {
          errorMessage = 'You do not have permission to request training';
        } else if (err.status === 404) {
          errorMessage = 'Request endpoint not found. Please restart the backend server.';
        } else if (err.error?.message) {
          errorMessage = err.error.message;
        }
        
        alert(errorMessage);
      }
    });
  }

  closeRequestForm(): void {
    this.showRequestForm = false;
    this.requestData = {
      reason: ''
    };
  }

  continueCourse(course: any): void {
    this.router.navigate(['/my-trainings']);
  }

  downloadCertificate(course: any): void {
    const employeeName = localStorage.getItem('userName') || 'Employee';
    const courseName = course.title;
    const completionDate = new Date().toLocaleDateString();

    this.certificateService.generateCertificate(
      employeeName,
      courseName,
      completionDate
    );
  }

  // ==================== ADMIN DASHBOARD ====================
  loadAdminDashboard(): void {
    this.courseService.getCourses().subscribe({
      next: (courseRes) => {
        this.courses = courseRes.courses;
        this.loading = false;
      },
      error: () => this.loading = false
    });

    // Load employees for assignment
    this.http.get<any>('http://localhost:5000/api/admin/employees')
      .subscribe({
        next: (res) => {
          this.employees = res.employees;
        },
        error: (err) => console.error('Failed to load employees:', err)
      });
  }

  openAssignModal(course: any): void {
    this.selectedCourseForAssign = course;
    this.selectedEmployeeIds = [];
    this.showAssignModal = true;
  }

  toggleEmployeeSelection(employeeId: string): void {
    const index = this.selectedEmployeeIds.indexOf(employeeId);
    if (index > -1) {
      this.selectedEmployeeIds.splice(index, 1);
    } else {
      this.selectedEmployeeIds.push(employeeId);
    }
  }

  isEmployeeSelected(employeeId: string): boolean {
    return this.selectedEmployeeIds.includes(employeeId);
  }

  submitAssignment(): void {
    if (this.selectedEmployeeIds.length === 0) {
      alert('Please select at least one employee');
      return;
    }

    let successCount = 0;
    let errorCount = 0;
    const totalAssignments = this.selectedEmployeeIds.length;

    this.selectedEmployeeIds.forEach((employeeId, index) => {
      this.enrollmentService.assignCourse(
        this.selectedCourseForAssign._id,
        employeeId
      ).subscribe({
        next: () => {
          successCount++;
          if (successCount + errorCount === totalAssignments) {
            this.showAssignmentResult(successCount, errorCount);
          }
        },
        error: (err) => {
          errorCount++;
          console.error('Assignment error:', err);
          if (successCount + errorCount === totalAssignments) {
            this.showAssignmentResult(successCount, errorCount);
          }
        }
      });
    });
  }

  showAssignmentResult(successCount: number, errorCount: number): void {
    if (successCount > 0) {
      alert(`Successfully assigned course to ${successCount} employee(s)${errorCount > 0 ? `. ${errorCount} failed.` : '!'}`);
    } else {
      alert('Failed to assign course to employees');
    }
    this.closeAssignModal();
  }

  closeAssignModal(): void {
    this.showAssignModal = false;
    this.selectedCourseForAssign = null;
    this.selectedEmployeeIds = [];
  }
}