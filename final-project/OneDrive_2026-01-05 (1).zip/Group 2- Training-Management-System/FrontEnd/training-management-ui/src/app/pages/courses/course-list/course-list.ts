import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../../services/course.service';
import { Course } from '../../../models/course.model';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-course-list',
  standalone:true,
  imports:[CommonModule],
  templateUrl: './course-list.html'
})
export class CourseListComponent implements OnInit {

  courses: Course[] = [];
  loading = true;

  constructor(private courseService: CourseService,
    private cdr:ChangeDetectorRef) { }

  ngOnInit(): void {
    console.log('Fetching courses...');

    this.courseService.getCourses().subscribe({
      next: (response) => {
        this.courses = response.courses;
        this.loading = false;
        this.cdr.detectChanges();
        console.log('Courses loaded:', this.courses);
      },
      error: (error) => {
        this.loading = false;
        console.error('Error loading courses:', error);
      }
    });
  }
}