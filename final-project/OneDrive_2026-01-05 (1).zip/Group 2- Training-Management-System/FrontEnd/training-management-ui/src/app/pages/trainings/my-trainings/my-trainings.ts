import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EnrollmentService } from '../../../services/enrollment.service';
import { CertificateService } from '../../../services/certificate.service';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { interval, Subscription } from 'rxjs';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-my-trainings',
  imports: [CommonModule],
  templateUrl: './my-trainings.html',
  styleUrl: './my-trainings.css',
  standalone: true
})
export class MyTrainingsComponent implements OnInit {

  enrollments: any[] = [];
  loading = true;
  role = localStorage.getItem('role');
  employeeId: string | null = null;
  isReadOnly = false;
  
  // Selected enrollment for viewing
  selectedEnrollment: any = null;
  showCourseView = false;
  
  // Time tracking
  timeSpent = 0;
  minimumTime = 30; // 30 seconds minimum
  timer: Subscription | null = null;
  timerStarted = false;
  isCompletionAllowed = false; // Track if user can complete the course

  constructor(
    private enrollmentService: EnrollmentService,
    private certificateService: CertificateService,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private sanitizer: DomSanitizer,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.employeeId = this.route.snapshot.paramMap.get('id');
    
    console.log('=== Component Init ===');
    console.log('Employee ID:', this.employeeId);
    console.log('Role:', this.role);
    
    if (this.employeeId && this.role === 'Admin') {
      this.isReadOnly = true;
      console.log('Admin mode - loading employee trainings');
      this.loadEmployeeTrainings(this.employeeId);
    } else {
      console.log('Employee mode - loading my trainings');
      this.loadMyTrainings();
    }
  }

  ngOnDestroy(): void {
    if (this.timer) {
      this.timer.unsubscribe();
    }
  }

  loadMyTrainings(): void {
    this.loading = true;
    this.enrollmentService.getMyTrainings().subscribe({
      next: (res) => {
        setTimeout(() => {
          this.enrollments = [...(res.enrollments || [])];
          this.loading = false;
        }, 0);
      },
      error: () => {
        setTimeout(() => {
          this.loading = false;
        }, 0);
      }
    });
  }

  loadEmployeeTrainings(employeeId: string): void {
    console.log('=== Loading Employee Trainings ===');
    console.log('Employee ID:', employeeId);
    
    this.loading = true;
    this.enrollments = [];
    
    this.enrollmentService.getEmployeeTrainings(employeeId).subscribe({
      next: (res) => {
        console.log('=== Response Received ===');
        console.log('Success:', res.success);
        console.log('Enrollments:', res.enrollments);
        console.log('Count:', res.enrollments?.length);
        
        // Force Angular to detect changes by wrapping in setTimeout
        setTimeout(() => {
          if (res && res.enrollments) {
            this.enrollments = [...res.enrollments]; // Create new array reference
            console.log('Enrollments assigned:', this.enrollments.length);
            
            // Log first enrollment details
            if (this.enrollments.length > 0) {
              console.log('First enrollment:', this.enrollments[0]);
            }
          }
          
          this.loading = false;
          console.log('Loading set to false');
          console.log('Final state - Loading:', this.loading, 'Enrollments:', this.enrollments.length);
        }, 0);
      },
      error: (err) => {
        console.error('=== Error Occurred ===');
        console.error('Status:', err.status);
        console.error('Message:', err.message);
        console.error('Error:', err);
        
        setTimeout(() => {
          this.enrollments = [];
          this.loading = false;
        }, 0);
      }
    });
  }

  openCourse(enrollment: any): void {
    this.selectedEnrollment = enrollment;
    this.showCourseView = true;
    this.timeSpent = enrollment.timeSpentInSeconds || 0;
    
    // Start timer only if not read-only and not completed
    if (!this.isReadOnly && enrollment.progressStatus !== 'Completed') {
      this.startTimer();
    }
  }

  closeCourseView(): void {
    this.showCourseView = false;
    this.stopTimer();
    this.selectedEnrollment = null;
  }

  startTimer(): void {
    if (this.timerStarted) return;
    
    this.timerStarted = true;
    this.isCompletionAllowed = false;
    let secondsCounter = 0;
    
    this.timer = interval(1000).subscribe(() => {
      this.timeSpent++;
      secondsCounter++;
      
      // Update completion allowed flag
      this.isCompletionAllowed = this.timeSpent >= this.minimumTime;
      
      // Trigger change detection every second for smooth countdown
      this.cdr.markForCheck();
      
      // Auto-save progress every 10 seconds
      if (secondsCounter >= 10) {
        this.saveProgress();
        secondsCounter = 0;
      }
    });
  }

  stopTimer(): void {
    if (this.timer) {
      this.timer.unsubscribe();
      this.timer = null;
    }
    this.timerStarted = false;
    
    // Save final progress when stopping
    if (this.selectedEnrollment && this.timeSpent > 0) {
      this.saveProgress();
    }
  }

  saveProgress(): void {
    if (!this.selectedEnrollment || this.isReadOnly) return;
    
    // Update progress status to "In Progress" if still assigned
    if (this.selectedEnrollment.progressStatus === 'Assigned') {
      this.selectedEnrollment.progressStatus = 'In Progress';
    }
    
    // Update the enrollment's time in real-time
    this.selectedEnrollment.timeSpentInSeconds = this.timeSpent;
    
    // Update in the enrollments array as well
    const index = this.enrollments.findIndex(e => e._id === this.selectedEnrollment._id);
    if (index !== -1) {
      this.enrollments[index].timeSpentInSeconds = this.timeSpent;
      this.enrollments[index].progressStatus = this.selectedEnrollment.progressStatus;
    }
    
    // Save time to backend (silently, no alerts)
    this.enrollmentService.updateProgress(
      this.selectedEnrollment._id,
      this.timeSpent
    ).subscribe({
      next: () => {
        console.log(`Progress saved: ${this.timeSpent} seconds`);
      },
      error: (err) => {
        console.error('Failed to save progress:', err);
      }
    });
  }

  canMarkComplete(): boolean {
    return this.isCompletionAllowed;
  }

  markComplete(): void {
    if (!this.canMarkComplete()) {
      alert(`You must spend at least ${this.minimumTime} seconds on this course.`);
      return;
    }

    this.stopTimer();
    
    this.enrollmentService.completeTraining(
      this.selectedEnrollment._id,
      this.timeSpent
    ).subscribe({
      next: () => {
        alert('Training completed successfully!');
        this.closeCourseView();
        // Reload the trainings list to show updated status
        if (this.employeeId && this.role === 'Admin') {
          this.loadEmployeeTrainings(this.employeeId);
        } else {
          this.loadMyTrainings();
        }
      },
      error: (err) => {
        alert(err.error?.message || 'Failed to mark as complete');
      }
    });
  }

  downloadCertificate(enrollment: any): void {
    const employeeName = localStorage.getItem('userName') || 'Employee';
    const courseName = enrollment.courseId.title;
    const completionDate = new Date(enrollment.completedAt).toLocaleDateString();

    this.certificateService.generateCertificate(
      employeeName,
      courseName,
      completionDate
    );
  }

  getSafeUrl(url: string): SafeResourceUrl {
    if (!url) return '';
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  goBack(): void {
    if (this.isReadOnly) {
      this.router.navigate(['/admin']);
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  formatTime(seconds: number): string {
    // Prevent negative time display
    const positiveSeconds = Math.max(0, seconds);
    const mins = Math.floor(positiveSeconds / 60);
    const secs = positiveSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
}
