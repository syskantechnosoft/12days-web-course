import { Component } from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone:true,
  templateUrl: './login.html',
  imports:[CommonModule,FormsModule],
  styleUrls: ['./login.css']
})
export class LoginComponent {

  email: string = '';
  password: string = '';
  errorMessage = '';
  passwordVisible: boolean = false;

  constructor(private authService: AuthService,
    private router:Router,
  
  ) { }

  onLogin(): void {
    this.errorMessage = '';
    console.log('Login attempt with:', this.email);

    this.authService.login(this.email, this.password).subscribe({
      next: (response) => {
        console.log('Login successful:', response);
        this.authService.saveAuthData(response);
        console.log('Navigating to dashboard');
        this.router.navigate(['/dashboard']).then(() => {
          console.log('Navigation complete');
        });
      },
      error: (error) => {
        console.error('Login error:', error);
        this.errorMessage = error.error?.message || 'Login failed';
      }
    });
  }

}