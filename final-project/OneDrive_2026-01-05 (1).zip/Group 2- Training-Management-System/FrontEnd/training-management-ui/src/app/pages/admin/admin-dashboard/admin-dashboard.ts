// import { Component, OnInit } from '@angular/core';
// import { CourseService } from '../../../services/course.service';
// import { EnrollmentService } from '../../../services/enrollment.service';
// import { AuthService } from '../../../services/auth.service';
// import { Course } from '../../../models/course.model';
// import { User } from '../../../models/user.model';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';

// @Component({
//   selector: 'app-admin-dashboard',
//   imports:[CommonModule,FormsModule],
//   templateUrl: './admin-dashboard.html'
// })
// export class AdminDashboardComponent implements OnInit {

//   courses: Course[] = [];
//   employees: User[] = [];

//   selectedCourseId = '';
//   selectedUserId = '';

//   message = '';

//   constructor(
//     private courseService: CourseService,
//     private enrollmentService: EnrollmentService,
//     private authService: AuthService
//   ) { }

//   ngOnInit(): void {
//     this.loadCourses();
//     this.loadEmployees();
//   }

//   loadCourses(): void {
//     this.courseService.getCourses().subscribe({
//       next: (res) => this.courses = res.courses
//     });
//   }

//   loadEmployees(): void {
//     this.authService.getEmployees().subscribe({
//       next: (res) => this.employees = res.users
//     });
//   }

  
 
//   assignCourse(): void {
//     console.log('Assign button clicked');
//     console.log('Selected course:', this.selectedCourseId);
//     console.log('Selected user:', this.selectedUserId);

//     this.message = '';

//     if (!this.selectedCourseId || !this.selectedUserId) {
//       this.message = 'Please select course and employee';
//       return;
//     }

//     this.enrollmentService.assignCourse(
//       this.selectedCourseId,
//       this.selectedUserId
//     ).subscribe({
//       next: () => {
//         console.log('API success');
//         this.message = 'Course assigned successfully';
//       },
//       error: (err) => {
//         console.error('API error', err);
//         this.message = err.error?.message || 'Assignment failed';
//       }
//     });
//   }

// }

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CourseService } from '../../../services/course.service';
import { EnrollmentService } from '../../../services/enrollment.service';

@Component({
  selector: 'app-admin-dashboard',
  imports:[CommonModule, FormsModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent implements OnInit {

  activeTab: 'employees' | 'trainers' | 'courses' | 'requests' = 'employees';

  employees: any[] = [];
  trainers: any[] = [];
  courses: any[] = [];
  pendingRequests: any[] = [];
  loading = true;

  // Add user form
  showAddUserForm = false;
  newUser = {
    name: '',
    email: '',
    password: '',
    role: 'Employee'
  };
  userMessage = '';

  // Add course form
  showAddCourseForm = false;
  newCourse = {
    title: '',
    description: '',
    duration: null as number | null,
    contentUrl: ''
  };
  courseMessage = '';

  // Upload Material Modal
  showUploadModal = false;
  selectedCourseForUpload: any = null;
  uploadData = {
    materialType: 'pdf',
    materialUrl: '',
    file: null as File | null
  };
  uploadMessage = '';

  // Assign Course Modal
  showAssignModal = false;
  selectedCourseForAssign: any = null;
  selectedEmployeeIds: string[] = [];
  assignMessage = '';

  // Employee Courses Modal
  showEmployeeCoursesModal = false;
  selectedEmployee: any = null;
  employeeCourses: any[] = [];
  loadingEmployeeCourses = false;

  // Request Details Modal
  showRequestDetailsModal = false;
  selectedRequest: any = null;
  rejectionReason = '';

  // Employee Requests Modal
  showEmployeeRequestsModal = false;
  selectedEmployeeForRequests: any = null;
  employeePendingRequests: any[] = [];

  constructor(
    private http: HttpClient,
    private router: Router,
    private courseService: CourseService,
    private enrollmentService: EnrollmentService
  ) { }

  ngOnInit(): void {
    // Load all data on init - employees visible by default
    this.loadAllData();
  }

  loadAllData(): void {
    this.loading = true;
    
    // Load employees
    this.http.get<any>('http://localhost:5000/api/admin/employees')
      .subscribe(res => {
        this.employees = res.employees;
        this.checkLoadingComplete();
      });

    // Load trainers
    this.http.get<any>('http://localhost:5000/api/admin/trainers')
      .subscribe(res => {
        this.trainers = res.trainers;
        this.checkLoadingComplete();
      });

    // Load courses
    this.courseService.getCourses().subscribe({
      next: (res) => {
        this.courses = res.courses;
        this.checkLoadingComplete();
      },
      error: () => this.checkLoadingComplete()
    });

    // Load pending requests
    this.enrollmentService.getPendingRequests().subscribe({
      next: (res) => {
        this.pendingRequests = res.requests;
        this.checkLoadingComplete();
      },
      error: () => this.checkLoadingComplete()
    });
  }

  checkLoadingComplete(): void {
    if (this.employees.length >= 0 && this.trainers.length >= 0 && this.courses.length >= 0) {
      this.loading = false;
    }
  }

  loadEmployees(): void {
    this.http.get<any>('http://localhost:5000/api/admin/employees')
      .subscribe(res => {
        this.employees = res.employees;
      });
  }

  loadTrainers(): void {
    this.http.get<any>('http://localhost:5000/api/admin/trainers')
      .subscribe(res => {
        this.trainers = res.trainers;
      });
  }

  switchTab(tab: 'employees' | 'trainers' | 'courses' | 'requests'): void {
    this.activeTab = tab;
    // No API call needed - data already loaded
  }

  toggleAddUserForm(): void {
    this.showAddUserForm = !this.showAddUserForm;
    this.userMessage = '';
    if (this.showAddUserForm) {
      this.showAddCourseForm = false;
    }
    if (!this.showAddUserForm) {
      // Reset form
      this.newUser = {
        name: '',
        email: '',
        password: '',
        role: 'Employee'
      };
    }
  }

  toggleAddCourseForm(): void {
    this.showAddCourseForm = !this.showAddCourseForm;
    this.courseMessage = '';
    if (this.showAddCourseForm) {
      this.showAddUserForm = false;
    }
    if (!this.showAddCourseForm) {
      // Reset form
      this.newCourse = {
        title: '',
        description: '',
        duration: null,
        contentUrl: ''
      };
    }
  }

  createUser(): void {
    this.userMessage = '';

    if (!this.newUser.name || !this.newUser.email || !this.newUser.password) {
      this.userMessage = 'All fields are required';
      return;
    }

    this.http.post<any>('http://localhost:5000/api/admin/create-user', this.newUser)
      .subscribe({
        next: (res) => {
          this.userMessage = res.message;
          // Reset form
          this.newUser = {
            name: '',
            email: '',
            password: '',
            role: 'Employee'
          };
          // Reload the appropriate list
          if (this.activeTab === 'employees') {
            this.loadEmployees();
          } else {
            this.loadTrainers();
          }
          // Hide form after 2 seconds
          setTimeout(() => {
            this.showAddUserForm = false;
            this.userMessage = '';
          }, 2000);
        },
        error: (err) => {
          this.userMessage = err.error?.message || 'Failed to create user';
        }
      });
  }

  createCourse(): void {
    this.courseMessage = '';

    if (!this.newCourse.title || !this.newCourse.description || !this.newCourse.duration) {
      this.courseMessage = 'Title, description, and duration are required';
      return;
    }

    this.courseService.createCourse(this.newCourse)
      .subscribe({
        next: (res) => {
          this.courseMessage = 'Course created successfully!';
          // Reset form
          this.newCourse = {
            title: '',
            description: '',
            duration: null,
            contentUrl: ''
          };
          // Reload courses
          this.courseService.getCourses().subscribe({
            next: (res) => {
              this.courses = res.courses;
            }
          });
          // Hide form after 2 seconds
          setTimeout(() => {
            this.showAddCourseForm = false;
            this.courseMessage = '';
          }, 2000);
        },
        error: (err) => {
          this.courseMessage = err.error?.message || 'Failed to create course';
        }
      });
  }

  exploreEmployee(employeeId: string): void {
    const employee = this.employees.find(e => e._id === employeeId);
    this.selectedEmployee = employee;
    this.showEmployeeCoursesModal = true;
    this.loadingEmployeeCourses = true;
    this.employeeCourses = [];

    this.enrollmentService.getEmployeeTrainings(employeeId).subscribe({
      next: (res) => {
        console.log('API Response:', res);
        // Map courseId to course for template compatibility
        const enrollments = (res.enrollments || []).map((enrollment: any) => ({
          ...enrollment,
          course: enrollment.courseId,
          status: enrollment.progressStatus || 'Assigned',
          progress: enrollment.progressStatus === 'Completed' ? 100 : 0
        }));
        this.employeeCourses = enrollments;
        console.log('Processed enrollments:', this.employeeCourses);
        this.loadingEmployeeCourses = false;
      },
      error: (err) => {
        console.error('Failed to load employee courses', err);
        this.loadingEmployeeCourses = false;
      }
    });
  }

  closeEmployeeCoursesModal(): void {
    this.showEmployeeCoursesModal = false;
    this.selectedEmployee = null;
    this.employeeCourses = [];
  }

  // ==================== UPLOAD MATERIAL ====================
  openUploadModal(course: any): void {
    this.selectedCourseForUpload = course;
    this.showUploadModal = true;
    this.uploadMessage = '';
  }

  closeUploadModal(): void {
    this.showUploadModal = false;
    this.selectedCourseForUpload = null;
    this.uploadData = {
      materialType: 'pdf',
      materialUrl: '',
      file: null
    };
    this.uploadMessage = '';
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.uploadData.file = file;
    }
  }

  submitMaterial(): void {
    console.log('=== Submit Material Called ===');
    console.log('Course:', this.selectedCourseForUpload);
    console.log('Upload Data:', this.uploadData);
    console.log('Material Type:', this.uploadData.materialType);
    console.log('Material URL:', this.uploadData.materialUrl);
    
    this.uploadMessage = '';

    // Validation
    if (this.uploadData.materialType === 'link') {
      if (!this.uploadData.materialUrl || this.uploadData.materialUrl.trim() === '') {
        console.log('❌ Validation failed: Empty URL');
        this.uploadMessage = '⚠️ Please provide a valid URL';
        console.log('Message set to:', this.uploadMessage);
        return;
      }
      // Basic URL validation
      if (!this.uploadData.materialUrl.startsWith('http://') && !this.uploadData.materialUrl.startsWith('https://')) {
        console.log('❌ Validation failed: Invalid URL format');
        this.uploadMessage = '⚠️ URL must start with http:// or https://';
        console.log('Message set to:', this.uploadMessage);
        return;
      }
    } else {
      if (!this.uploadData.file) {
        console.log('❌ Validation failed: No file selected');
        this.uploadMessage = '⚠️ Please select a file to upload';
        console.log('Message set to:', this.uploadMessage);
        return;
      }
    }

    if (!this.selectedCourseForUpload || !this.selectedCourseForUpload._id) {
      this.uploadMessage = '⚠️ No course selected';
      console.error('No course selected');
      return;
    }

    // Get the material URL (either from input or file name)
    const materialUrl = this.uploadData.materialType === 'link' 
      ? this.uploadData.materialUrl 
      : `uploaded-${this.uploadData.materialType}-${this.uploadData.file?.name || 'file'}`;
    
    console.log('Updating course contentUrl to:', materialUrl);
    console.log('Making PATCH request to:', `http://localhost:5000/api/courses/${this.selectedCourseForUpload._id}`);
    
    this.http.patch(`http://localhost:5000/api/courses/${this.selectedCourseForUpload._id}`, {
      contentUrl: materialUrl
    }).subscribe({
      next: (res) => {
        console.log('✅ Material uploaded successfully:', res);
        this.uploadMessage = '✓ Material uploaded successfully!';
        console.log('Success message set to:', this.uploadMessage);
        
        // Also show browser alert for confirmation
        alert('✓ Material uploaded successfully!');
        
        setTimeout(() => {
          console.log('Closing modal and refreshing data');
          this.closeUploadModal();
          this.loadAllData();
        }, 3000); // Increased from 2000 to 3000ms
      },
      error: (err) => {
        console.error('❌ Failed to upload material:', err);
        console.error('Error status:', err.status);
        console.error('Error message:', err.error?.message || err.message);
        
        // Handle 401 Unauthorized specifically
        if (err.status === 401) {
          this.uploadMessage = '🔒 Session expired. Please login again.';
          alert('🔒 Your session has expired. Please login again.');
          
          // Redirect to login after 2 seconds
          setTimeout(() => {
            localStorage.clear();
            this.router.navigate(['/login']);
          }, 2000);
        } else {
          const errorMessage = err.error?.message || err.message || 'Server error';
          this.uploadMessage = `✗ Failed to upload material: ${errorMessage}`;
          alert(`✗ Failed to upload material: ${errorMessage}`);
        }
        
        console.log('Error message set to:', this.uploadMessage);
      }
    });
  }

  // ==================== ASSIGN COURSE ====================
  openAssignModal(course: any): void {
    this.selectedCourseForAssign = course;
    this.selectedEmployeeIds = [];
    this.showAssignModal = true;
    this.assignMessage = '';
  }

  closeAssignModal(): void {
    this.showAssignModal = false;
    this.selectedCourseForAssign = null;
    this.selectedEmployeeIds = [];
    this.assignMessage = '';
  }

  toggleEmployeeSelection(employeeId: string): void {
    const index = this.selectedEmployeeIds.indexOf(employeeId);
    if (index > -1) {
      this.selectedEmployeeIds.splice(index, 1);
    } else {
      this.selectedEmployeeIds.push(employeeId);
    }
  }

  isEmployeeSelected(employeeId: string): boolean {
    return this.selectedEmployeeIds.includes(employeeId);
  }

  submitAssignment(): void {
    console.log('=== Submit Assignment Called ===');
    console.log('Selected Employee IDs:', this.selectedEmployeeIds);
    console.log('Selected Course:', this.selectedCourseForAssign);
    
    if (this.selectedEmployeeIds.length === 0) {
      this.assignMessage = 'Please select at least one employee';
      return;
    }

    if (!this.selectedCourseForAssign || !this.selectedCourseForAssign._id) {
      this.assignMessage = 'No course selected';
      console.error('No course selected or course ID missing');
      return;
    }

    let successCount = 0;
    let errorCount = 0;
    const totalAssignments = this.selectedEmployeeIds.length;
    const errors: string[] = [];

    console.log(`Starting ${totalAssignments} assignment(s)`);

    this.selectedEmployeeIds.forEach((employeeId, index) => {
      console.log(`Assignment ${index + 1}: Course ${this.selectedCourseForAssign._id} -> Employee ${employeeId}`);
      
      this.enrollmentService.assignCourse(
        this.selectedCourseForAssign._id,
        employeeId
      ).subscribe({
        next: (res) => {
          successCount++;
          console.log(`✅ Assignment ${index + 1} successful:`, res);
          if (successCount + errorCount === totalAssignments) {
            this.showAssignmentResult(successCount, errorCount, errors);
          }
        },
        error: (err) => {
          errorCount++;
          const errorMsg = err.error?.message || err.message || 'Unknown error';
          errors.push(errorMsg);
          console.error(`❌ Assignment ${index + 1} failed:`, err);
          console.error('Error status:', err.status);
          console.error('Error message:', errorMsg);
          if (successCount + errorCount === totalAssignments) {
            this.showAssignmentResult(successCount, errorCount, errors);
          }
        }
      });
    });
  }

  showAssignmentResult(successCount: number, errorCount: number, errors: string[] = []): void {
    console.log('=== Assignment Results ===');
    console.log('Success:', successCount, 'Errors:', errorCount);
    if (errors.length > 0) {
      console.log('Error messages:', errors);
    }

    if (successCount > 0) {
      this.assignMessage = `Successfully assigned to ${successCount} employee(s)${errorCount > 0 ? `. ${errorCount} failed.` : '!'}`;
    } else {
      this.assignMessage = `Failed to assign course. ${errors[0] || 'Unknown error'}`;
    }
    
    setTimeout(() => {
      this.closeAssignModal();
      if (successCount > 0) {
        this.loadAllData(); // Refresh data if any assignments succeeded
      }
    }, 2000);
  }

  // ==================== TRAINING REQUESTS ====================
  getEmployeePendingRequests(employeeId: string): any[] {
    return this.pendingRequests.filter(req => req.userId?._id === employeeId);
  }

  viewEmployeeRequests(employee: any): void {
    this.selectedEmployeeForRequests = employee;
    this.employeePendingRequests = this.getEmployeePendingRequests(employee._id);
    this.showEmployeeRequestsModal = true;
  }

  closeEmployeeRequestsModal(): void {
    this.showEmployeeRequestsModal = false;
    this.selectedEmployeeForRequests = null;
    this.employeePendingRequests = [];
  }

  openRequestDetails(request: any): void {
    this.selectedRequest = request;
    this.showRequestDetailsModal = true;
    this.rejectionReason = '';
  }

  closeRequestDetailsModal(): void {
    this.showRequestDetailsModal = false;
    this.selectedRequest = null;
    this.rejectionReason = '';
  }

  approveTrainingRequest(requestId: string): void {
    this.enrollmentService.approveRequest(requestId).subscribe({
      next: (res) => {
        alert('Training request approved successfully!');
        this.closeRequestDetailsModal();
        this.closeEmployeeRequestsModal();
        // Reload pending requests
        this.enrollmentService.getPendingRequests().subscribe({
          next: (res) => {
            this.pendingRequests = res.requests;
          }
        });
      },
      error: (err) => {
        alert(err.error?.message || 'Failed to approve request');
      }
    });
  }

  rejectTrainingRequest(requestId: string): void {
    if (!this.rejectionReason || this.rejectionReason.trim() === '') {
      alert('Please provide a rejection reason');
      return;
    }

    this.enrollmentService.rejectRequest(requestId, this.rejectionReason).subscribe({
      next: (res) => {
        alert('Training request rejected');
        this.closeRequestDetailsModal();
        this.closeEmployeeRequestsModal();
        // Reload pending requests
        this.enrollmentService.getPendingRequests().subscribe({
          next: (res) => {
            this.pendingRequests = res.requests;
          }
        });
      },
      error: (err) => {
        alert(err.error?.message || 'Failed to reject request');
      }
    });
  }
}