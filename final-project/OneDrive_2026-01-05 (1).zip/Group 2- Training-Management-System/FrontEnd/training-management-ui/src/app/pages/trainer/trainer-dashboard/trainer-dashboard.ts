import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-trainer-dashboard',
  imports: [CommonModule],
  templateUrl: './trainer-dashboard.html',
  styleUrl: './trainer-dashboard.css',
})


export class TrainerDashboardComponent implements OnInit {

  courses: any[] = [];
  enrollments: any[] = [];
  loading = true;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http
      .get<any>('http://localhost:5000/api/courses/trainer')
      .subscribe({
        next: (res) => {
          this.courses = res.courses;
          this.enrollments = res.enrollments;
          this.loading = false;
        },
        error: (err) => {
          console.error('Trainer dashboard error:', err);
          this.loading = false;
        }
      });
  }
}
