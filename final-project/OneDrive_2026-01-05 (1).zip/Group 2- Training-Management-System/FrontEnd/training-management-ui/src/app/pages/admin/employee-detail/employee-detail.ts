import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { CourseService } from '../../../services/course.service';
import { EnrollmentService } from '../../../services/enrollment.service';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employee-detail.html',
  styleUrls: ['./employee-detail.css']
})
export class EmployeeDetailComponent implements OnInit {
  employeeId: string = '';
  employee: any = null;
  courses: any[] = [];
  loading = true;
  message = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private courseService: CourseService,
    private enrollmentService: EnrollmentService
  ) {}

  ngOnInit(): void {
    this.employeeId = this.route.snapshot.paramMap.get('id') || '';
    if (this.employeeId) {
      this.loadEmployeeDetails();
      this.loadCourses();
    }
  }

  loadEmployeeDetails(): void {
    this.http.get<any>(`http://localhost:5000/api/admin/employees`)
      .subscribe({
        next: (res) => {
          this.employee = res.employees.find((e: any) => e._id === this.employeeId);
          if (!this.employee) {
            this.message = 'Employee not found';
          }
        },
        error: (err) => {
          this.message = 'Failed to load employee details';
          console.error(err);
        }
      });
  }

  loadCourses(): void {
    this.courseService.getCourses().subscribe({
      next: (response) => {
        this.courses = response.courses;
        this.loading = false;
      },
      error: (error) => {
        this.loading = false;
        this.message = 'Failed to load courses';
        console.error('Error loading courses:', error);
      }
    });
  }

  assignCourse(courseId: string): void {
    this.message = '';
    
    if (!this.employeeId || !courseId) {
      this.message = 'Invalid employee or course';
      return;
    }

    this.enrollmentService.assignCourse(courseId, this.employeeId).subscribe({
      next: (res: any) => {
        this.message = res.message || 'Course assigned successfully';
        setTimeout(() => {
          this.message = '';
        }, 3000);
      },
      error: (err) => {
        this.message = err.error?.message || 'Failed to assign course';
        setTimeout(() => {
          this.message = '';
        }, 3000);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/admin']);
  }
}
