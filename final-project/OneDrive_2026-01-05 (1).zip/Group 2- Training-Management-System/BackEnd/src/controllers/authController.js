const bcrypt = require('bcrypt');
const User = require('../models/User');

const jwtUtils = require('../utils/token');
exports.register = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User already exists'
            });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create user
        const user = await User.create({
            name,
            email,
            password: hashedPassword,
            role
        });

        console.log('New user registered:', user.email);

        res.status(201).json({
            success: true,
            message: 'User registered successfully'
        });

    } catch (error) {
        console.error('Register error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check user
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        // Generate tokens
        const accessToken = jwtUtils.generateAccessToken(user);
        const refreshToken = jwtUtils.generateRefreshToken(user);

        console.log('User logged in:', user.email);

        res.status(200).json({
            success: true,
            accessToken,
            refreshToken,
            role: user.role,
            userName: user.name,
            userId: user._id
        });

    } catch (error) {
        console.error('Login error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
exports.getEmployees = async (req, res) => {
    try {
        const users = await User.find({ role: 'Employee' })
            .select('_id name email');

        res.status(200).json({
            success: true,
            users
        });
    } catch (error) {
        console.error('Get employees error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};