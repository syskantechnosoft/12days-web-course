const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');

exports.createCourse = async (req, res) => {
    try {
        const { title, description, duration, contentUrl } = req.body;

        const course = await Course.create({
            title,
            description,
            duration,
            contentUrl,
            createdBy: req.user.id
        });

        console.log('Course created:', course.title);

        res.status(201).json({
            success: true,
            message: 'Course created successfully',
            course
        });

    } catch (error) {
        console.error('Create course error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};


exports.getCourses = async (req, res) => {
    try {
        const courses = await Course.find({ isActive: true });

        res.status(200).json({
            success: true,
            courses
        });
    } catch (error) {
        console.error('Get courses error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

exports.updateCourse = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, duration, contentUrl } = req.body;

        const course = await Course.findById(id);

        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        // Update fields if provided
        if (title !== undefined) course.title = title;
        if (description !== undefined) course.description = description;
        if (duration !== undefined) course.duration = duration;
        if (contentUrl !== undefined) course.contentUrl = contentUrl;

        await course.save();

        console.log('Course updated:', course.title);

        res.status(200).json({
            success: true,
            message: 'Course updated successfully',
            course
        });

    } catch (error) {
        console.error('Update course error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// exports.getTrainerCourses = async (req, res) => {
//     try {
//         const trainerId = req.user.id;

//         const courses = await Course.find({ createdBy: trainerId });

//         const courseIds = courses.map(c => c._id);

//         const enrollments = await Enrollment.find({
//             courseId: { $in: courseIds }
//         })
//             .populate('userId', 'name email')
//             .populate('courseId', 'title');

//         res.status(200).json({
//             success: true,
//             courses,
//             enrollments
//         });
//     } catch (error) {
//         console.error('Trainer courses error:', error.message);
//         res.status(500).json({
//             success: false,
//             message: 'Server error'
//         });
//     }
// };

exports.getTrainerCourses = async (req, res) => {
    try {
        // Get all enrollments
        const enrollments = await Enrollment.find()
            .populate('userId', 'name email')
            .populate('courseId', 'title description duration');

        if (!enrollments.length) {
            return res.status(200).json({
                success: true,
                courses: [],
                enrollments: []
            });
        }

        // Extract unique courses from enrollments
        const courseMap = {};
        enrollments.forEach(enroll => {
            courseMap[enroll.courseId._id] = enroll.courseId;
        });

        const courses = Object.values(courseMap);

        res.status(200).json({
            success: true,
            courses,
            enrollments
        });

    } catch (error) {
        console.error('Trainer courses error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};