const User = require('../models/User');
const bcrypt = require('bcrypt');

// Get all employees
exports.getEmployees = async (req, res) => {
    try {
        const employees = await User.find({ role: 'Employee' })
            .select('name email joiningDate');

        res.status(200).json({ success: true, employees });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Get all trainers
exports.getTrainers = async (req, res) => {
    try {
        const trainers = await User.find({ role: 'Trainer' })
            .select('name email joiningDate expertise');

        res.status(200).json({ success: true, trainers });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Create a new user (Employee or Trainer)
exports.createUser = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        // Validate required fields
        if (!name || !email || !password || !role) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User with this email already exists'
            });
        }

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create user
        const user = await User.create({
            name,
            email,
            password: hashedPassword,
            role
        });

        res.status(201).json({
            success: true,
            message: 'User created successfully',
            user: {
                _id: user._id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });

    } catch (error) {
        console.error('Create user error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};