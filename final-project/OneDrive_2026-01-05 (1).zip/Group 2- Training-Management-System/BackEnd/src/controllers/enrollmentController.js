const Enrollment = require('../models/Enrollment');
const User=require('../models/User');
const Course=require('../models/Course');

exports.assignCourse = async (req, res) => {
    try {
        const { courseId, userId } = req.body;

        const existingEnrollment = await Enrollment.findOne({
            courseId,
            userId
        });

        if(existingEnrollment){
            const user= await User.findById(userId).select('name');
            const course=await Course.findById(courseId).select('title');
            return res.status(400).json({
                success: false,
                message: `Course "${course.title}" is already assigned to "${user.name}"`
            });
        }

        const enrollment = await Enrollment.create({
            courseId,
            userId
        });

        console.log('Course assigned:', courseId, 'to user:', userId);

        res.status(201).json({
            success: true,
            message: 'Course assigned successfully',
            enrollment
        });

    } catch (error) {
        console.error('Assign course error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
exports.updateProgress = async (req, res) => {
    try {
        const { enrollmentId, timeSpentInSeconds } = req.body;

        const enrollment = await Enrollment.findById(enrollmentId);

        if (!enrollment) {
            return res.status(404).json({
                success: false,
                message: 'Enrollment not found'
            });
        }

        // Don't update if already completed
        if (enrollment.progressStatus === 'Completed') {
            return res.status(200).json({
                success: true,
                message: 'Training already completed'
            });
        }

        // Update time spent and set status to "In Progress"
        enrollment.timeSpentInSeconds = timeSpentInSeconds;
        if (enrollment.progressStatus === 'Assigned' && timeSpentInSeconds > 0) {
            enrollment.progressStatus = 'In Progress';
        }

        await enrollment.save();

        console.log('Progress updated:', enrollment._id, 'Time:', timeSpentInSeconds);

        res.status(200).json({
            success: true,
            message: 'Progress updated successfully'
        });

    } catch (error) {
        console.error('Update progress error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
exports.completeTraining = async (req, res) => {
    try {
        const { enrollmentId, timeSpentInSeconds } = req.body;

        const enrollment = await Enrollment.findById(enrollmentId);

        if (!enrollment) {
            return res.status(404).json({
                success: false,
                message: 'Enrollment not found'
            });
        }

        // Only assigned or in progress allowed
        if (enrollment.progressStatus === 'Completed') {
            return res.status(400).json({
                success: false,
                message: 'Training already completed'
            });
        }

        const MIN_REQUIRED_TIME = 30;

        if (timeSpentInSeconds < MIN_REQUIRED_TIME) {
            return res.status(400).json({
                success: false,
                message: `You must spend at least ${MIN_REQUIRED_TIME} seconds to complete this training`
            });
        }

        enrollment.progressStatus = 'Completed';
        enrollment.completedAt = new Date();
        enrollment.timeSpentInSeconds = timeSpentInSeconds;

        await enrollment.save();

        console.log('Training completed:', enrollment._id);

        res.status(200).json({
            success: true,
            message: 'Training marked as completed'
        });

    } catch (error) {
        console.error('Complete training error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
exports.getMyTrainings = async (req, res) => {
    try {
        const userId = req.user.id;

        const enrollments = await Enrollment.find({ userId })
            .populate('courseId', 'title description duration contentUrl')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            enrollments
        });

    } catch (error) {
        console.error('Get my trainings error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Admin: Get specific employee's trainings
exports.getEmployeeTrainings = async (req, res) => {
    try {
        const { employeeId } = req.params;
        
        console.log('Getting trainings for employee:', employeeId);

        const enrollments = await Enrollment.find({ userId: employeeId })
            .populate('courseId', 'title description duration contentUrl')
            .sort({ createdAt: -1 });

        console.log('Found enrollments:', enrollments.length);
        
        // Log each enrollment details
        enrollments.forEach((e, index) => {
            console.log(`Enrollment ${index + 1}:`, {
                id: e._id,
                courseId: e.courseId ? e.courseId._id : 'NULL',
                courseTitle: e.courseId ? e.courseId.title : 'NULL',
                status: e.progressStatus
            });
        });

        res.status(200).json({
            success: true,
            enrollments
        });

    } catch (error) {
        console.error('Get employee trainings error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Employee: Request Training
exports.requestTraining = async (req, res) => {
    try {
        console.log('=== Request Training ===');
        console.log('User:', req.user);
        console.log('Body:', req.body);
        
        const { courseId, reason } = req.body;
        const userId = req.user.id;

        if (!courseId || !reason) {
            return res.status(400).json({
                success: false,
                message: 'Course ID and reason are required'
            });
        }

        // Check if already enrolled or requested
        const existingEnrollment = await Enrollment.findOne({
            courseId,
            userId
        });

        if (existingEnrollment) {
            console.log('Existing enrollment found:', existingEnrollment.requestStatus);
            if (existingEnrollment.requestStatus === 'Pending') {
                return res.status(400).json({
                    success: false,
                    message: 'You already have a pending request for this course'
                });
            }
            if (existingEnrollment.requestStatus === 'Approved' || existingEnrollment.requestStatus === 'None') {
                return res.status(400).json({
                    success: false,
                    message: 'You are already enrolled in this course'
                });
            }
        }

        // Create enrollment with pending status
        const enrollment = await Enrollment.create({
            courseId,
            userId,
            requestStatus: 'Pending',
            requestReason: reason,
            requestedBy: 'Employee',
            progressStatus: 'Assigned'
        });

        await enrollment.populate('courseId', 'title description');
        await enrollment.populate('userId', 'name email');

        console.log('Training request created:', enrollment._id);

        res.status(201).json({
            success: true,
            message: 'Training request submitted successfully',
            enrollment
        });

    } catch (error) {
        console.error('Request training error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Server error'
        });
    }
};

// Admin: Get all pending training requests
exports.getPendingRequests = async (req, res) => {
    try {
        const requests = await Enrollment.find({ 
            requestStatus: 'Pending',
            requestedBy: 'Employee'
        })
            .populate('courseId', 'title description duration')
            .populate('userId', 'name email')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            requests
        });

    } catch (error) {
        console.error('Get pending requests error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Admin: Approve training request
exports.approveRequest = async (req, res) => {
    try {
        const { requestId } = req.params;

        const enrollment = await Enrollment.findById(requestId)
            .populate('courseId', 'title')
            .populate('userId', 'name email');

        if (!enrollment) {
            return res.status(404).json({
                success: false,
                message: 'Request not found'
            });
        }

        if (enrollment.requestStatus !== 'Pending') {
            return res.status(400).json({
                success: false,
                message: 'Request has already been processed'
            });
        }

        enrollment.requestStatus = 'Approved';
        await enrollment.save();

        console.log('Training request approved:', requestId);

        res.status(200).json({
            success: true,
            message: 'Training request approved successfully',
            enrollment
        });

    } catch (error) {
        console.error('Approve request error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Admin: Reject training request
exports.rejectRequest = async (req, res) => {
    try {
        const { requestId } = req.params;
        const { rejectionReason } = req.body;

        const enrollment = await Enrollment.findById(requestId)
            .populate('courseId', 'title')
            .populate('userId', 'name email');

        if (!enrollment) {
            return res.status(404).json({
                success: false,
                message: 'Request not found'
            });
        }

        if (enrollment.requestStatus !== 'Pending') {
            return res.status(400).json({
                success: false,
                message: 'Request has already been processed'
            });
        }

        enrollment.requestStatus = 'Rejected';
        enrollment.rejectionReason = rejectionReason || 'No reason provided';
        await enrollment.save();

        console.log('Training request rejected:', requestId);

        res.status(200).json({
            success: true,
            message: 'Training request rejected',
            enrollment
        });

    } catch (error) {
        console.error('Reject request error:', error.message);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};
