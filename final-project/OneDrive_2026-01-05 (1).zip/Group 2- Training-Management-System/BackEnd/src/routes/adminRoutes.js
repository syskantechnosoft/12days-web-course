const express = require('express');
const router = express.Router();

const { verifyToken, authorizeRoles } = require('../middlewares/authMiddleware');
const { getEmployees, getTrainers, createUser } = require('../controllers/adminController');

router.get(
    '/employees',
    verifyToken,
    authorizeRoles('Admin'),
    getEmployees
);

router.get(
    '/trainers',
    verifyToken,
    authorizeRoles('Admin'),
    getTrainers
);

router.post(
    '/create-user',
    verifyToken,
    authorizeRoles('Admin'),
    createUser
);

module.exports = router;