const express = require('express');
const { register,login ,getEmployees} = require('../controllers/authController');
const { verifyToken, authorizeRoles } = require('../middlewares/authMiddleware');

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/employees',
    verifyToken,
    authorizeRoles('Admin'),
    getEmployees
);

module.exports = router;