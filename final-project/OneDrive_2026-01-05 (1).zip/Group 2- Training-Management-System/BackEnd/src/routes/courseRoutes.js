const express = require('express');
const { createCourse, getTrainerCourses, updateCourse } = require('../controllers/CourseController');
const { verifyToken, authorizeRoles } = require('../middlewares/authMiddleware');
const { getCourses} =require('../controllers/CourseController')

const router = express.Router();

// Admin & Trainer only
router.post(
    '/',
    verifyToken,
    authorizeRoles('Admin', 'Trainer'),
    createCourse
);

// Admin & Trainer - Update course (e.g., upload material)
router.patch(
    '/:id',
    verifyToken,
    authorizeRoles('Admin', 'Trainer'),
    updateCourse
);

router.get(
    '/trainer',
    verifyToken,
    authorizeRoles('Trainer'),
    getTrainerCourses
);
router.get(
    '/',
    verifyToken,
    getCourses
);

module.exports = router;