const express = require('express');
const { verifyToken, authorizeRoles } = require('../middlewares/authMiddleware');

const router = express.Router();

// Any logged-in user
router.get('/profile', verifyToken, (req, res) => {
    res.json({
        success: true,
        message: 'Access granted',
        user: req.user
    });
});

// Admin-only route
router.get('/admin', verifyToken, authorizeRoles('Admin'), (req, res) => {
    res.json({
        success: true,
        message: 'Admin access granted'
    });
});

module.exports = router;