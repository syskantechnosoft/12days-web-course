const express = require('express');
const { 
    assignCourse, 
    completeTraining, 
    getMyTrainings, 
    getEmployeeTrainings,
    requestTraining,
    getPendingRequests,
    approveRequest,
    rejectRequest,
    updateProgress
} = require('../controllers/enrollmentController');
const { verifyToken, authorizeRoles } = require('../middlewares/authMiddleware');


const router = express.Router();

// Test endpoint to check all enrollments (for debugging)
router.get('/all', verifyToken, authorizeRoles('Admin'), async (req, res) => {
    try {
        const Enrollment = require('../models/Enrollment');
        const enrollments = await Enrollment.find()
            .populate('courseId', 'title')
            .populate('userId', 'name email');
        res.json({ success: true, count: enrollments.length, enrollments });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Admin only
router.post(
    '/',
    verifyToken,
    authorizeRoles('Admin'),
    assignCourse
);
router.patch(
    '/complete',
    verifyToken,
    authorizeRoles('Employee'),
    completeTraining
);
router.get(
    '/my',
    verifyToken,
    authorizeRoles('Employee'),
    getMyTrainings
);
router.get(
    '/employee/:employeeId',
    verifyToken,
    authorizeRoles('Admin'),
    getEmployeeTrainings
);

// Employee: Request training
router.post(
    '/request',
    verifyToken,
    authorizeRoles('Employee'),
    requestTraining
);

// Employee: Update progress (auto-save timer)
router.patch(
    '/progress',
    verifyToken,
    authorizeRoles('Employee'),
    updateProgress
);

// Admin: Get pending requests
router.get(
    '/pending-requests',
    verifyToken,
    authorizeRoles('Admin'),
    getPendingRequests
);

// Admin: Approve request
router.patch(
    '/approve/:requestId',
    verifyToken,
    authorizeRoles('Admin'),
    approveRequest
);

// Admin: Reject request
router.patch(
    '/reject/:requestId',
    verifyToken,
    authorizeRoles('Admin'),
    rejectRequest
);

module.exports = router; 