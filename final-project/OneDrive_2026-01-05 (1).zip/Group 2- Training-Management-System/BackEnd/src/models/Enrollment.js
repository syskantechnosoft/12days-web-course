const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema(
    {
        courseId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Course',
            required: true
        },
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true
        },
        timeSpentInSeconds: {
            type: Number,
            default: 0
        },
        progressStatus: {
            type: String,
            enum: ['Assigned', 'In Progress', 'Completed'],
            default: 'Assigned'
        },
        requestStatus: {
            type: String,
            enum: ['Pending', 'Approved', 'Rejected', 'None'],
            default: 'None'
        },
        requestReason: {
            type: String
        },
        requestedBy: {
            type: String,
            enum: ['Employee', 'Admin'],
            default: 'Admin'
        },
        rejectionReason: {
            type: String
        },
        assignedAt: {
            type: Date,
            default: Date.now
        },
        completedAt: {
            type: Date
        }
    },
    {
        timestamps: true
    }

);

module.exports = mongoose.model('Enrollment', enrollmentSchema);
